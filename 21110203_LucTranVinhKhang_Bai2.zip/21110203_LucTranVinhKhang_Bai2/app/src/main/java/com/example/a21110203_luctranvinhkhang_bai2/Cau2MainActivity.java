package com.example.a21110203_luctranvinhkhang_bai2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;

public class Cau2MainActivity extends AppCompatActivity {

    // khai báo
    Switch sw;
    ConstraintLayout background;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cau2_main);
        // ánh xạ
        sw = (Switch) findViewById(R.id.switchBGround);
        background = (ConstraintLayout) findViewById(R.id.background_main);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    background.setBackgroundResource(R.drawable.bg3);
                }else{
                    background.setBackgroundResource(R.drawable.bg4);
                }
            }
        });
    }
}