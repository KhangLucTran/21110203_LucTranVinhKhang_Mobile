package com.example.a21110203_luctranvinhkhang_bai2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

@SuppressLint("UseSwitchCompatOrMaterialCode")
public class SwitchActivity extends AppCompatActivity {

    // Khai báo Switch
    Switch sw;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switch);
        // ánh xạ Switch
        sw = (Switch) findViewById(R.id.switch1);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){ //isChecked = true
                    Toast.makeText(SwitchActivity.this,"Wifi đang bật",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(SwitchActivity.this,"Wifi đang tắt",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}