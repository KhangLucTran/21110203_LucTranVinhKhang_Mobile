package com.example.a21110203_luctranvinhkhang_bai2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Random;

public class Cau1MainActivity extends AppCompatActivity {

    // Khai báo ImageView
    ImageView img1;
    // Khai báo ConstraintLayout
    ConstraintLayout bg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // anh xa ImageView
        img1= (ImageView) findViewById(R.id.imageView);
        img1.setImageResource(R.drawable.img);

        // anhxa ConstraintLayout.
        bg = (ConstraintLayout) findViewById(R.id.constraintLayout1);
        bg.setBackgroundResource(R.drawable.bg1);

        // Random Background
        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add(R.drawable.bg1);
        arrayList.add(R.drawable.bg2);
        arrayList.add(R.drawable.bg3);
        arrayList.add(R.drawable.bg4);

        Random random = new Random();
        int vitri = random.nextInt(arrayList.size());
        bg.setBackgroundResource(arrayList.get(vitri));
    }
}